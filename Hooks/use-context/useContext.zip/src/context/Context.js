import { createContext } from "react";

export const counterContext = createContext(0)