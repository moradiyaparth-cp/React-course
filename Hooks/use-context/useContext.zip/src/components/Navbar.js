import React from 'react'
import Button from './Button'

const Navbar = () => {
  return (
    <div>
        Navbar
        <Button />
    </div>
  )
}

export default Navbar